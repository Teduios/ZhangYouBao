//
//  VideoCollectionViewCell.m
//  BaseProject
//
//  Created by apple-jd17 on 15/11/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoCollectionViewCell.h"

@implementation VideoCollectionViewCell

@end
