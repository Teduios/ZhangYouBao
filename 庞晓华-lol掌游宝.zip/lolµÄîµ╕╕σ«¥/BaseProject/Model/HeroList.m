//
//  HeroList.m
//  BaseProject
//
//  Created by apple-jd17 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HeroList.h"

@implementation HeroList

+(NSDictionary *)objectClassInArray{
    return @{@"data":[HeroListData class]};
}

@end

@implementation HeroListData



@end

