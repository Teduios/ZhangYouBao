//
//  VideoViewController.h
//  BaseProject
//
//  Created by apple-jd17 on 15/11/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VideoViewModel.h"
@interface VideoViewController : UICollectionViewController
@property(nonatomic)videoList type;
@end
