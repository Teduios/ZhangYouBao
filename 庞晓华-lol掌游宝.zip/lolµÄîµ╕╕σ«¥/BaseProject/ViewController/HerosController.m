//
//  HerosController.m
//  BaseProject
//
//  Created by apple-jd17 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HerosController.h"
#import "TRImageView.h"
#import "HerosViewModel.h"
#import "HeroDetailController.h"

@interface FreeHerosCell : UITableViewCell
/** 英雄头像 */
@property(nonatomic,strong)TRImageView *imageVC;
/** 英雄中文名字 */
@property(nonatomic,strong)UILabel *nameLb;
/** 金币 */
@property(nonatomic,strong)UILabel *costLb;
@property(nonatomic,strong)UILabel *moneyLb;

@property(nonatomic,strong)TRImageView *costImg;
@property(nonatomic,strong)TRImageView *moneyImg;

@end

@implementation FreeHerosCell

-(TRImageView *)imageVC{
    if (!_imageVC) {
        _imageVC = [[TRImageView alloc]init];
        [self.contentView addSubview:_imageVC];
        [_imageVC mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(8);
            make.centerY.mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(50, 50));
        }];
    }
    return _imageVC;
}

-(UILabel *)nameLb{
    if (!_nameLb) {
        _nameLb = [UILabel new];
        [self.contentView addSubview:_nameLb];
        _nameLb.font = [UIFont systemFontOfSize:12];
        _nameLb.textColor = [UIColor lightGrayColor];
        [_nameLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(5);
            make.left.mas_equalTo(self.imageVC.mas_right).mas_equalTo(5);
            make.right.mas_equalTo(-5);
        }];
    }
    return _nameLb;
}

-(TRImageView *)moneyImg{
    if (!_moneyImg) {
        _moneyImg = [[TRImageView alloc]init];
        [self.contentView addSubview:_moneyImg];
        [_moneyImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.imageVC.mas_right).mas_equalTo(5);
            make.top.mas_equalTo(self.nameLb.mas_bottom).mas_equalTo(5);
            make.width.height.mas_equalTo(17);
        }];
    }
    return _moneyImg;
}


-(UILabel *)moneyLb{
    if (!_moneyLb) {
        _moneyLb = [UILabel new];
        [self.contentView addSubview:_moneyLb];
        _moneyLb.font = [UIFont systemFontOfSize:12];
        _moneyLb.textColor = [UIColor lightGrayColor];
        [_moneyLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.moneyImg.mas_right).mas_equalTo(5);
            make.top.mas_equalTo(self.nameLb.mas_bottom).mas_equalTo(5);
            make.width.mas_equalTo(35);
        }];
    }
    return _moneyLb;
}




-(TRImageView *)costImg{
    if (!_costImg) {
        _costImg = [[TRImageView alloc]init];
        [self.contentView addSubview:_costImg];
        [_costImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.moneyLb.mas_right).mas_equalTo(5);
            make.top.mas_equalTo(self.nameLb.mas_bottom).mas_equalTo(5);
            make.width.height.mas_equalTo(17);
        }];
    }
    return _costImg;
}


-(UILabel *)costLb{
    if (!_costLb) {
        _costLb = [UILabel new];
        [self.contentView addSubview:_costLb];
        _costLb.font = [UIFont systemFontOfSize:12];
        _costLb.textColor = [UIColor lightGrayColor];
        [_costLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.costImg.mas_right).mas_equalTo(5);
            make.top.mas_equalTo(self.nameLb.mas_bottom).mas_equalTo(5);
            make.width.mas_equalTo(35);
        }];
    }
    return _costLb;
}


@end



@interface HerosController ()<UITableViewDataSource,UITableViewDelegate>

@property(nonatomic,strong)UITableView *tableVM;
@property(nonatomic,strong)HerosViewModel *heroVM;
@end

@implementation HerosController



-(UITableView *)tableVM{
    if (!_tableVM) {
        _tableVM = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableVM.rowHeight = 60;
        _tableVM.delegate = self;
        _tableVM.dataSource = self;

    }
    
    return _tableVM;
}

-(HerosViewModel *)heroVM{
    if (!_heroVM) {
        _heroVM = [HerosViewModel new];
    }
    return _heroVM;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view addSubview:self.tableVM];
    [self.tableVM mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    self.tableVM.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
       [self.heroVM refreshDataCompletionHandle:^(NSError *error) {
           if (error) {
               [self showErrorMsg:error.localizedDescription];
           }
           [self.tableVM reloadData];
           
       }];
        [self.tableVM.header endRefreshing];
    }];
    
    [self.tableVM.header beginRefreshing];
    
    [self.tableVM registerClass:[FreeHerosCell class] forCellReuseIdentifier:@"Cell"];
    self.title = @"周免英雄";
    
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.heroVM.rowNum;
}

/** 返回每一位英雄的json数据转化为的字典 */
-(NSDictionary *)dicWithID:(NSString *)ID{
    NSString *path = [[NSBundle mainBundle]pathForResource:ID ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSError *error = nil;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
    return dic;
}



-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    FreeHerosCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    NSString *Id = [self.heroVM IDForRow:indexPath.row];
    
    NSDictionary *dic = [self dicWithID:Id];
    
    /** 先从返回的字典中取到英雄的英文名，然后将它作为图片的名字加载到cell */
    [cell.imageVC.imageView setImage:[UIImage imageNamed:[dic valueForKey:@"duoname"]]];
    /** 取英雄的中文名 */
    cell.nameLb.text = [dic valueForKey:@"nickname"];
    /** 英雄点卷 */
    cell.costLb.text = [dic valueForKey:@"point"];
    /** 英雄点卷图片 */
    [cell.costImg.imageView setImage:[UIImage imageNamed:@"cell_point"]];
    /** 英雄金币 */
    cell.moneyLb.text = [dic valueForKey:@"money"];
    /** 英雄金币图片 */
    [cell.moneyImg.imageView setImage:[UIImage imageNamed:@"cell_money"]];
    
    return cell;
}

kRemoveCellSeparator
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSString *Id = [self.heroVM IDForRow:indexPath.row];
    NSDictionary *dic = [self dicWithID:Id];
    HeroDetailController *vc = [HeroDetailController new];
    vc.dictionary = dic;
    [self.navigationController pushViewController:vc animated:YES];
}


@end
